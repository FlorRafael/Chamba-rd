package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import com.example.data.models.User
import com.example.data.models.UserRole
import com.example.ui.theme.*
import com.example.ui.viewmodels.MainViewModel
import com.example.ui.viewmodels.Screen
import kotlinx.coroutines.launch

@Composable
fun ProfileScreen(viewModel: MainViewModel) {
    val currentUser by viewModel.currentUser.collectAsState()
    val scope = rememberCoroutineScope()
    var showEditDialog by remember { mutableStateOf(false) }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
            .statusBarsPadding()
    ) {
        Surface(
            color = MaterialTheme.colorScheme.surface,
            tonalElevation = 2.dp,
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(modifier = Modifier.padding(16.dp)) {
                Text(
                    text = "Mi Perfil",
                    style = MaterialTheme.typography.titleLarge.copy(
                        fontWeight = FontWeight.Black,
                        color = ChambaNavyPrimary
                    )
                )
            }
        }

        if (currentUser == null) {
            Box(
                modifier = Modifier.fillMaxSize(),
                contentAlignment = Alignment.Center
            ) {
                Button(onClick = { viewModel.navigateTo(Screen.Login) }) {
                    Text("Iniciar Sesión")
                }
            }
            return
        }

        val u = currentUser!!

        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .testTag("profile_scroll_list"),
            contentPadding = PaddingValues(16.dp)
        ) {
            // Profile Card
            item {
                Card(
                    shape = RoundedCornerShape(20.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                    elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(20.dp),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        AsyncImage(
                            model = u.fotoPerfil.ifEmpty { "https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?w=400" },
                            contentDescription = u.nombre,
                            modifier = Modifier
                                .size(80.dp)
                                .clip(CircleShape),
                            contentScale = ContentScale.Crop
                        )

                        Spacer(modifier = Modifier.height(12.dp))

                        Text(
                            text = u.nombre,
                            style = MaterialTheme.typography.titleLarge.copy(
                                fontWeight = FontWeight.Bold,
                                color = ChambaNavyPrimary
                            )
                        )

                        Text(
                            text = u.email,
                            style = MaterialTheme.typography.bodySmall.copy(color = MaterialTheme.colorScheme.onSurfaceVariant)
                        )

                        Spacer(modifier = Modifier.height(8.dp))

                        Surface(
                            shape = RoundedCornerShape(12.dp),
                            color = when (u.getRoleEnum()) {
                                UserRole.TRABAJADOR -> ChambaAmber
                                UserRole.ADMIN -> DominicanRed
                                else -> ChambaNavyPrimary
                            }
                        ) {
                            Text(
                                text = "ROL: ${u.getRoleEnum().displayName.uppercase()}",
                                color = Color.White,
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Bold,
                                modifier = Modifier.padding(horizontal = 12.dp, vertical = 4.dp)
                            )
                        }

                        Spacer(modifier = Modifier.height(16.dp))

                        OutlinedButton(
                            onClick = { showEditDialog = true },
                            shape = RoundedCornerShape(10.dp),
                            modifier = Modifier.fillMaxWidth().testTag("edit_profile_button")
                        ) {
                            Icon(Icons.Default.Edit, contentDescription = null, modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(8.dp))
                            Text("Editar Datos del Perfil")
                        }
                    }
                }

                Spacer(modifier = Modifier.height(16.dp))
            }

            // Quick Role Switcher for instant testing
            item {
                Card(
                    shape = RoundedCornerShape(16.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f)),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Text("Cambiar de Usuario / Rol de Prueba", fontWeight = FontWeight.Bold, fontSize = 13.sp)
                        Spacer(modifier = Modifier.height(8.dp))
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(6.dp)
                        ) {
                            Button(
                                onClick = { viewModel.switchRoleForTesting(UserRole.CLIENTE) },
                                colors = ButtonDefaults.buttonColors(
                                    containerColor = if (u.getRoleEnum() == UserRole.CLIENTE) ChambaNavyPrimary else Color.Gray
                                ),
                                shape = RoundedCornerShape(8.dp),
                                modifier = Modifier.weight(1f).testTag("switch_to_client_btn")
                            ) {
                                Text("Cliente", fontSize = 11.sp)
                            }
                            Button(
                                onClick = { viewModel.switchRoleForTesting(UserRole.TRABAJADOR) },
                                colors = ButtonDefaults.buttonColors(
                                    containerColor = if (u.getRoleEnum() == UserRole.TRABAJADOR) ChambaAmberDark else Color.Gray
                                ),
                                shape = RoundedCornerShape(8.dp),
                                modifier = Modifier.weight(1f).testTag("switch_to_worker_btn")
                            ) {
                                Text("Trabajador", fontSize = 11.sp)
                            }
                            Button(
                                onClick = { viewModel.switchRoleForTesting(UserRole.ADMIN) },
                                colors = ButtonDefaults.buttonColors(
                                    containerColor = if (u.getRoleEnum() == UserRole.ADMIN) DominicanRed else Color.Gray
                                ),
                                shape = RoundedCornerShape(8.dp),
                                modifier = Modifier.weight(1f).testTag("switch_to_admin_btn")
                            ) {
                                Text("Admin", fontSize = 11.sp)
                            }
                        }
                    }
                }
                Spacer(modifier = Modifier.height(16.dp))
            }

            // Menu Items
            item {
                Card(
                    shape = RoundedCornerShape(16.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column {
                        if (u.esTrabajador) {
                            ProfileMenuItem(
                                title = "Mis Ingresos y Finanzas",
                                subtitle = "Balance acumulado, pagos y comisiones",
                                icon = Icons.Default.AccountBalanceWallet,
                                iconColor = ChambaEmeraldDark,
                                onClick = { viewModel.navigateTo(Screen.Incomes) }
                            )
                            Divider()
                        }

                        if (u.esAdmin) {
                            ProfileMenuItem(
                                title = "Panel de Administración",
                                subtitle = "Métricas, moderación de reportes y disputas",
                                icon = Icons.Default.AdminPanelSettings,
                                iconColor = DominicanRed,
                                onClick = { viewModel.navigateTo(Screen.AdminDashboard) }
                            )
                            Divider()
                        }

                        ProfileMenuItem(
                            title = "Notificaciones",
                            subtitle = "Alertas de postulaciones y cambios de estado",
                            icon = Icons.Default.Notifications,
                            iconColor = ChambaBlueAccent,
                            onClick = { viewModel.navigateTo(Screen.Notifications) }
                        )
                        Divider()

                        ProfileMenuItem(
                            title = "Mis Chambas",
                            subtitle = "Historial y seguimiento activo",
                            icon = Icons.Default.Work,
                            iconColor = ChambaNavyPrimary,
                            onClick = { viewModel.navigateTo(Screen.MyChambas) }
                        )
                    }
                }

                Spacer(modifier = Modifier.height(20.dp))
            }

            // Logout Button
            item {
                Button(
                    onClick = { viewModel.logout() },
                    shape = RoundedCornerShape(12.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = DominicanRed.copy(alpha = 0.12f)),
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(48.dp)
                        .testTag("logout_button")
                ) {
                    Icon(Icons.Default.ExitToApp, contentDescription = null, tint = DominicanRed)
                    Spacer(modifier = Modifier.width(8.dp))
                    Text("CERRAR SESIÓN", color = DominicanRed, fontWeight = FontWeight.Bold)
                }
                Spacer(modifier = Modifier.height(60.dp))
            }
        }
    }

    if (showEditDialog && currentUser != null) {
        EditProfileDialog(
            user = currentUser!!,
            onDismiss = { showEditDialog = false },
            onSave = { updated ->
                scope.launch {
                    viewModel.authRepo.updateUserProfile(updated)
                    viewModel.showMessage("Perfil actualizado con éxito.")
                    showEditDialog = false
                }
            }
        )
    }
}

@Composable
fun ProfileMenuItem(
    title: String,
    subtitle: String,
    icon: ImageVector,
    iconColor: Color,
    onClick: () -> Unit
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clickable { onClick() }
            .padding(16.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Box(
            modifier = Modifier
                .size(40.dp)
                .clip(CircleShape)
                .background(iconColor.copy(alpha = 0.12f)),
            contentAlignment = Alignment.Center
        ) {
            Icon(icon, contentDescription = null, tint = iconColor, modifier = Modifier.size(20.dp))
        }

        Spacer(modifier = Modifier.width(12.dp))

        Column(modifier = Modifier.weight(1f)) {
            Text(title, fontWeight = FontWeight.Bold, fontSize = 14.sp)
            Text(subtitle, fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }

        Icon(Icons.Default.ChevronRight, contentDescription = null, tint = Color.Gray)
    }
}

@Composable
fun EditProfileDialog(
    user: User,
    onDismiss: () -> Unit,
    onSave: (User) -> Unit
) {
    var telefono by remember { mutableStateOf(user.telefono) }
    var zona by remember { mutableStateOf(user.zona) }
    var descripcion by remember { mutableStateOf(user.descripcion) }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Editar Perfil", fontWeight = FontWeight.Bold) },
        text = {
            Column(modifier = Modifier.fillMaxWidth()) {
                OutlinedTextField(
                    value = telefono,
                    onValueChange = { telefono = it },
                    label = { Text("Teléfono / WhatsApp") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )
                Spacer(modifier = Modifier.height(10.dp))
                OutlinedTextField(
                    value = zona,
                    onValueChange = { zona = it },
                    label = { Text("Zona / Sector") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )
                Spacer(modifier = Modifier.height(10.dp))
                OutlinedTextField(
                    value = descripcion,
                    onValueChange = { descripcion = it },
                    label = { Text("Descripción") },
                    minLines = 3,
                    modifier = Modifier.fillMaxWidth()
                )
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    onSave(
                        user.copy(
                            telefono = telefono,
                            zona = zona,
                            descripcion = descripcion
                        )
                    )
                },
                colors = ButtonDefaults.buttonColors(containerColor = ChambaNavyPrimary)
            ) {
                Text("GUARDAR CAMBIOS", fontWeight = FontWeight.Bold)
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) { Text("Cancelar") }
        }
    )
}

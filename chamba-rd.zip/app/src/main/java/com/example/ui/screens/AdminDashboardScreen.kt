package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.models.Category
import com.example.data.models.Chamba
import com.example.data.models.Dispute
import com.example.data.models.Report
import com.example.ui.components.StateBadge
import com.example.ui.theme.*
import com.example.ui.viewmodels.MainViewModel
import com.example.ui.viewmodels.Screen

@Composable
fun AdminDashboardScreen(viewModel: MainViewModel) {
    val currentUser by viewModel.currentUser.collectAsState()
    val allChambas by viewModel.chambaRepo.chambasState.collectAsState()
    val allReports by viewModel.reportDisputeRepo.reportsState.collectAsState()
    val allDisputes by viewModel.reportDisputeRepo.disputesState.collectAsState()
    val categories by viewModel.categoryRepo.categoriesState.collectAsState()

    var selectedTab by remember { mutableStateOf(0) }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
            .statusBarsPadding()
    ) {
        // Admin Header
        Surface(
            color = ChambaNavyDark,
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(modifier = Modifier.padding(16.dp)) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    IconButton(onClick = { viewModel.navigateTo(Screen.Home) }) {
                        Icon(Icons.Default.ArrowBack, contentDescription = "Atrás", tint = Color.White)
                    }
                    Spacer(modifier = Modifier.width(8.dp))
                    Column {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Default.AdminPanelSettings, contentDescription = null, tint = DominicanRed, modifier = Modifier.size(20.dp))
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(
                                text = "Panel de Administración",
                                style = MaterialTheme.typography.titleLarge.copy(
                                    fontWeight = FontWeight.Black,
                                    color = Color.White
                                )
                            )
                        }
                        Text(
                            text = "CHAMBA RD — Moderación y métricas de plataforma",
                            style = MaterialTheme.typography.bodySmall.copy(color = Color.White.copy(alpha = 0.8f))
                        )
                    }
                }

                Spacer(modifier = Modifier.height(12.dp))

                TabRow(
                    selectedTabIndex = selectedTab,
                    containerColor = ChambaNavyDark,
                    contentColor = Color.White
                ) {
                    Tab(
                        selected = selectedTab == 0,
                        onClick = { selectedTab = 0 },
                        text = { Text("Métricas", fontSize = 11.sp, color = if (selectedTab == 0) ChambaAmber else Color.White) }
                    )
                    Tab(
                        selected = selectedTab == 1,
                        onClick = { selectedTab = 1 },
                        text = { Text("Chambas (${allChambas.size})", fontSize = 11.sp, color = if (selectedTab == 1) ChambaAmber else Color.White) }
                    )
                    Tab(
                        selected = selectedTab == 2,
                        onClick = { selectedTab = 2 },
                        text = { Text("Reportes (${allReports.size})", fontSize = 11.sp, color = if (selectedTab == 2) ChambaAmber else Color.White) }
                    )
                    Tab(
                        selected = selectedTab == 3,
                        onClick = { selectedTab = 3 },
                        text = { Text("Categorías", fontSize = 11.sp, color = if (selectedTab == 3) ChambaAmber else Color.White) }
                    )
                }
            }
        }

        when (selectedTab) {
            0 -> {
                // Metrics Overview
                val totalVolume = allChambas.sumOf { it.precio }
                val completedCount = allChambas.count { it.estado == "completada" }
                val activeDisputesCount = allDisputes.count { it.estado == "abierta" || it.estado == "en_revision" }

                LazyColumn(
                    modifier = Modifier
                        .fillMaxSize()
                        .testTag("admin_metrics_list"),
                    contentPadding = PaddingValues(16.dp)
                ) {
                    item {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(10.dp)
                        ) {
                            MetricCard(
                                title = "Volumen Total",
                                value = "RD$ ${String.format("%,.0f", totalVolume)}",
                                subtitle = "En transacciones registradas",
                                color = ChambaNavyPrimary,
                                modifier = Modifier.weight(1f)
                            )
                            MetricCard(
                                title = "Chambas Creadas",
                                value = "${allChambas.size}",
                                subtitle = "$completedCount completadas",
                                color = ChambaEmeraldDark,
                                modifier = Modifier.weight(1f)
                            )
                        }
                        Spacer(modifier = Modifier.height(10.dp))
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(10.dp)
                        ) {
                            MetricCard(
                                title = "Disputas Abiertas",
                                value = "$activeDisputesCount",
                                subtitle = "Atención requerida",
                                color = if (activeDisputesCount > 0) DominicanRed else ChambaEmeraldDark,
                                modifier = Modifier.weight(1f)
                            )
                            MetricCard(
                                title = "Categorías Activas",
                                value = "${categories.size}",
                                subtitle = "Servicios disponibles",
                                color = ChambaBlueAccent,
                                modifier = Modifier.weight(1f)
                            )
                        }
                    }
                }
            }
            1 -> {
                // Chambas List
                LazyColumn(
                    modifier = Modifier.fillMaxSize(),
                    contentPadding = PaddingValues(16.dp)
                ) {
                    items(allChambas) { ch ->
                        Card(
                            shape = RoundedCornerShape(12.dp),
                            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(vertical = 4.dp)
                        ) {
                            Column(modifier = Modifier.padding(12.dp)) {
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Text(ch.titulo, fontWeight = FontWeight.Bold, fontSize = 13.sp, modifier = Modifier.weight(1f))
                                    StateBadge(state = ch.estadoEnum)
                                }
                                Spacer(modifier = Modifier.height(4.dp))
                                Text("Cliente: ${ch.clienteNombre} • ${ch.ubicacion}", fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                Text("Presupuesto: ${ch.precioFormateado}", fontSize = 12.sp, fontWeight = FontWeight.Bold, color = DominicanRed)
                            }
                        }
                    }
                }
            }
            2 -> {
                // Reports & Disputes List
                LazyColumn(
                    modifier = Modifier.fillMaxSize(),
                    contentPadding = PaddingValues(16.dp)
                ) {
                    item {
                        Text("Reportes de Usuarios", fontWeight = FontWeight.Bold, fontSize = 14.sp)
                        Spacer(modifier = Modifier.height(6.dp))
                    }
                    items(allReports) { rep ->
                        Card(
                            shape = RoundedCornerShape(12.dp),
                            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(vertical = 4.dp)
                        ) {
                            Column(modifier = Modifier.padding(12.dp)) {
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween
                                ) {
                                    Text("Motivo: ${rep.motivo}", fontWeight = FontWeight.Bold, fontSize = 13.sp, color = DominicanRed)
                                    Text(rep.estado.uppercase(), fontSize = 10.sp, fontWeight = FontWeight.Bold)
                                }
                                Spacer(modifier = Modifier.height(4.dp))
                                Text("Reportado por: ${rep.reporterNombre} a ${rep.reportedUserNombre}", fontSize = 11.sp)
                                Text("Detalle: ${rep.descripcion}", fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                            }
                        }
                    }

                    item {
                        Spacer(modifier = Modifier.height(16.dp))
                        Text("Disputas de Trabajo", fontWeight = FontWeight.Bold, fontSize = 14.sp)
                        Spacer(modifier = Modifier.height(6.dp))
                    }
                    items(allDisputes) { disp ->
                        Card(
                            shape = RoundedCornerShape(12.dp),
                            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(vertical = 4.dp)
                        ) {
                            Column(modifier = Modifier.padding(12.dp)) {
                                Text("Chamba: ${disp.chambaTitulo}", fontWeight = FontWeight.Bold, fontSize = 13.sp)
                                Text("Motivo: ${disp.motivo}", fontSize = 11.sp, color = DominicanRed)
                                Text("Descripción: ${disp.descripcion}", fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                            }
                        }
                    }
                }
            }
            3 -> {
                // Categories
                LazyColumn(
                    modifier = Modifier.fillMaxSize(),
                    contentPadding = PaddingValues(16.dp)
                ) {
                    items(categories) { cat ->
                        Card(
                            shape = RoundedCornerShape(12.dp),
                            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(vertical = 4.dp)
                        ) {
                            Column(modifier = Modifier.padding(12.dp)) {
                                Text(cat.nombre, fontWeight = FontWeight.Bold, fontSize = 14.sp, color = ChambaNavyPrimary)
                                Text(cat.descripcion, fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                Spacer(modifier = Modifier.height(4.dp))
                                Text("Subcategorías: ${cat.subcategorias.joinToString(", ")}", fontSize = 10.sp)
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun MetricCard(
    title: String,
    value: String,
    subtitle: String,
    color: Color,
    modifier: Modifier = Modifier
) {
    Card(
        shape = RoundedCornerShape(14.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        modifier = modifier
    ) {
        Column(modifier = Modifier.padding(14.dp)) {
            Text(title, fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
            Spacer(modifier = Modifier.height(4.dp))
            Text(value, fontSize = 18.sp, fontWeight = FontWeight.Black, color = color)
            Spacer(modifier = Modifier.height(2.dp))
            Text(subtitle, fontSize = 10.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
    }
}

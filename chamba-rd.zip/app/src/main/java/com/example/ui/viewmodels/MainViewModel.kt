package com.example.ui.viewmodels

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.models.*
import com.example.data.repository.*
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch

sealed class Screen {
    data object Home : Screen()
    data object Search : Screen()
    data object PublishChamba : Screen()
    data class ChambaDetail(val chambaId: String) : Screen()
    data class WorkerProfile(val workerId: String) : Screen()
    data object MyChambas : Screen()
    data object Messages : Screen()
    data class ChatConversation(val chambaId: String, val otherUserId: String, val otherUserName: String) : Screen()
    data object Notifications : Screen()
    data object Incomes : Screen()
    data object AdminDashboard : Screen()
    data object Profile : Screen()
    data object Login : Screen()
    data object Register : Screen()
    data object ForgotPassword : Screen()
}

class MainViewModel(application: Application) : AndroidViewModel(application) {

    val authRepo = AuthRepository()
    val chambaRepo = ChambaRepository()
    val notificationRepo = NotificationRepository()
    val postulacionRepo = PostulacionRepository(chambaRepo, notificationRepo)
    val chatRepo = ChatRepository()
    val reviewRepo = ReviewRepository(authRepo)
    val reportDisputeRepo = ReportDisputeRepository()
    val paymentRepo = PaymentRepository()
    val categoryRepo = CategoryRepository()

    // Navigation State
    private val _currentScreen = MutableStateFlow<Screen>(Screen.Home)
    val currentScreen = _currentScreen.asStateFlow()

    // UI Feedback Message
    private val _userMessage = MutableStateFlow<String?>(null)
    val userMessage = _userMessage.asStateFlow()

    // Search and Filter State
    private val _searchQuery = MutableStateFlow("")
    val searchQuery = _searchQuery.asStateFlow()

    private val _selectedCategoryId = MutableStateFlow<String?>(null)
    val selectedCategoryId = _selectedCategoryId.asStateFlow()

    private val _selectedProvince = MutableStateFlow<String?>("Todas")
    val selectedProvince = _selectedProvince.asStateFlow()

    private val _maxPriceFilter = MutableStateFlow<Double?>(null)
    val maxPriceFilter = _maxPriceFilter.asStateFlow()

    // Current User
    val currentUser = authRepo.currentUserState

    // Filtered Chambas
    val filteredChambas: StateFlow<List<Chamba>> = combine(
        chambaRepo.chambasState,
        _searchQuery,
        _selectedCategoryId,
        _selectedProvince,
        _maxPriceFilter
    ) { list, query, catId, province, maxPrice ->
        list.filter { chamba ->
            val matchesQuery = query.isEmpty() ||
                chamba.titulo.contains(query, ignoreCase = true) ||
                chamba.descripcion.contains(query, ignoreCase = true) ||
                chamba.ubicacion.contains(query, ignoreCase = true) ||
                chamba.categoriaNombre.contains(query, ignoreCase = true)

            val matchesCategory = catId == null || chamba.categoriaId.equals(catId, ignoreCase = true)
            val matchesPrice = maxPrice == null || chamba.precio <= maxPrice
            val matchesProvince = province == null || province == "Todas" || 
                chamba.ubicacion.contains(province.replace(" (D.N.)", "").replace(" (SDE)", "").replace(" (SDN)", "").replace(" (SDO)", "").replace(" (Santiago)", ""), ignoreCase = true)

            matchesQuery && matchesCategory && matchesPrice && matchesProvince
        }
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    // Unread Notifications Count
    val unreadNotificationsCount: StateFlow<Int> = notificationRepo.notificationsState.map { list ->
        val uid = currentUser.value?.uid ?: ""
        list.count { !it.leida && (it.userId == uid || it.userId.isEmpty()) }
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), 0)

    fun navigateTo(screen: Screen) {
        _currentScreen.value = screen
    }

    fun showMessage(msg: String) {
        _userMessage.value = msg
    }

    fun clearMessage() {
        _userMessage.value = null
    }

    fun setSearchQuery(query: String) {
        _searchQuery.value = query
    }

    fun setSelectedCategory(catId: String?) {
        _selectedCategoryId.value = catId
    }

    fun setSelectedProvince(province: String?) {
        _selectedProvince.value = province
    }

    fun setMaxPrice(max: Double?) {
        _maxPriceFilter.value = max
    }

    fun switchRoleForTesting(role: UserRole) {
        authRepo.switchRoleForTesting(role)
        showMessage("Cambiado a vista de ${role.displayName}")
    }

    fun register(
        nombre: String,
        email: String,
        telefono: String,
        pass: String,
        confirmPass: String,
        rol: UserRole,
        onSuccess: () -> Unit
    ) {
        viewModelScope.launch {
            val result = authRepo.register(nombre, email, telefono, pass, confirmPass, rol)
            result.onSuccess {
                showMessage("¡Bienvenido a CHAMBA RD, ${it.nombre}!")
                _currentScreen.value = Screen.Home
                onSuccess()
            }.onFailure {
                showMessage(it.message ?: "Error al registrarse.")
            }
        }
    }

    fun login(email: String, pass: String, onSuccess: () -> Unit) {
        viewModelScope.launch {
            val result = authRepo.login(email, pass)
            result.onSuccess {
                showMessage("Sesión iniciada con éxito.")
                _currentScreen.value = Screen.Home
                onSuccess()
            }.onFailure {
                showMessage(it.message ?: "Error al iniciar sesión.")
            }
        }
    }

    fun sendPasswordReset(email: String) {
        viewModelScope.launch {
            authRepo.sendPasswordReset(email)
            showMessage("Si el correo está registrado, recibirás un enlace de recuperación.")
        }
    }

    fun logout() {
        authRepo.logout()
        _currentScreen.value = Screen.Login
        showMessage("Has cerrado sesión.")
    }

    fun publishChamba(
        titulo: String,
        descripcion: String,
        categoriaId: String,
        categoriaNombre: String,
        ubicacion: String,
        fecha: String,
        hora: String,
        precio: Double,
        materialesResponsable: String,
        costoMateriales: Double,
        fotos: List<String>,
        onSuccess: (String) -> Unit
    ) {
        val user = currentUser.value
        if (user == null) {
            showMessage("Debes iniciar sesión para publicar una chamba.")
            return
        }
        viewModelScope.launch {
            val result = chambaRepo.createChamba(
                cliente = user,
                titulo = titulo,
                descripcion = descripcion,
                categoriaId = categoriaId,
                categoriaNombre = categoriaNombre,
                ubicacion = ubicacion,
                fechaTrabajo = fecha,
                horaTrabajo = hora,
                precio = precio,
                materialesResponsable = materialesResponsable,
                costoMateriales = costoMateriales,
                fotos = fotos
            )
            result.onSuccess { created ->
                // Registrar pago pendiente/retenido
                paymentRepo.recordPayment(
                    chambaId = created.id,
                    chambaTitulo = created.titulo,
                    clienteId = user.uid,
                    trabajadorId = "",
                    monto = created.precio,
                    estado = "retenido"
                )
                showMessage("¡Chamba publicada con éxito!")
                onSuccess(created.id)
            }.onFailure {
                showMessage(it.message ?: "Error al publicar la chamba.")
            }
        }
    }

    fun applyToChamba(
        chamba: Chamba,
        mensaje: String,
        precioPropuesto: Double,
        onSuccess: () -> Unit
    ) {
        val user = currentUser.value
        if (user == null) {
            showMessage("Debes iniciar sesión para postularte.")
            return
        }
        viewModelScope.launch {
            val result = postulacionRepo.createPostulacion(
                chamba = chamba,
                trabajador = user,
                mensaje = mensaje,
                precioPropuesto = precioPropuesto
            )
            result.onSuccess {
                showMessage("¡Te has postulado con éxito a la chamba!")
                onSuccess()
            }.onFailure {
                showMessage(it.message ?: "Error al postularse.")
            }
        }
    }

    fun selectWorker(
        chamba: Chamba,
        postulacion: Postulacion,
        onSuccess: () -> Unit
    ) {
        viewModelScope.launch {
            val result = postulacionRepo.selectTrabajador(chamba, postulacion)
            result.onSuccess {
                showMessage("¡Has seleccionado a ${postulacion.trabajadorNombre}!")
                onSuccess()
            }.onFailure {
                showMessage(it.message ?: "Error al seleccionar trabajador.")
            }
        }
    }

    fun startWork(chambaId: String) {
        val user = currentUser.value ?: return
        viewModelScope.launch {
            val result = chambaRepo.updateChambaState(
                chambaId = chambaId,
                newState = ChambaState.EN_PROCESO
            )
            result.onSuccess {
                val chamba = chambaRepo.getChambaById(chambaId)
                if (chamba != null) {
                    notificationRepo.sendNotification(
                        userId = chamba.clienteId,
                        titulo = "Trabajo iniciado",
                        mensaje = "${user.nombre} ha iniciado las labores en tu chamba «${chamba.titulo}».",
                        tipo = "estado",
                        chambaId = chambaId
                    )
                }
                showMessage("¡Has iniciado la chamba! Trabaja con calidad y seguridad.")
            }
        }
    }

    fun finishWork(chambaId: String, notas: String, evidenciaFotos: List<String>) {
        val user = currentUser.value ?: return
        viewModelScope.launch {
            val result = chambaRepo.updateChambaState(
                chambaId = chambaId,
                newState = ChambaState.TRABAJO_TERMINADO,
                notasTerminado = notas,
                evidenciaFotos = evidenciaFotos
            )
            result.onSuccess {
                val chamba = chambaRepo.getChambaById(chambaId)
                if (chamba != null) {
                    notificationRepo.sendNotification(
                        userId = chamba.clienteId,
                        titulo = "Trabajo terminado - Revisión pendiente",
                        mensaje = "${user.nombre} ha finalizado la chamba «${chamba.titulo}» y subió evidencias fotográficas.",
                        tipo = "estado",
                        chambaId = chambaId
                    )
                }
                showMessage("¡Trabajo marcado como terminado! El cliente ha recibido la notificación de revisión.")
            }
        }
    }

    fun confirmWork(chambaId: String) {
        viewModelScope.launch {
            val result = chambaRepo.updateChambaState(
                chambaId = chambaId,
                newState = ChambaState.COMPLETADA
            )
            result.onSuccess {
                paymentRepo.releasePayment(chambaId)
                val chamba = chambaRepo.getChambaById(chambaId)
                if (chamba != null && chamba.trabajadorSeleccionadoId.isNotEmpty()) {
                    notificationRepo.sendNotification(
                        userId = chamba.trabajadorSeleccionadoId,
                        titulo = "¡Trabajo confirmado y pago liberado!",
                        mensaje = "El cliente ha aprobado el trabajo de «${chamba.titulo}». Tu pago ha sido liberado.",
                        tipo = "estado",
                        chambaId = chambaId
                    )
                }
                showMessage("¡Trabajo confirmado satisfactoriamente! Fondos liberados.")
            }
        }
    }

    fun sendChatMessage(chambaId: String, receiverId: String, mensaje: String) {
        val user = currentUser.value ?: return
        viewModelScope.launch {
            val result = chatRepo.sendMessage(
                chambaId = chambaId,
                senderId = user.uid,
                senderNombre = user.nombre,
                receiverId = receiverId,
                mensaje = mensaje
            )
            result.onSuccess {
                notificationRepo.sendNotification(
                    userId = receiverId,
                    titulo = "Nuevo mensaje de ${user.nombre}",
                    mensaje = mensaje.take(60),
                    tipo = "chat",
                    chambaId = chambaId
                )
            }
        }
    }

    fun submitReview(
        chambaId: String,
        chambaTitulo: String,
        receptorId: String,
        puntuacion: Double,
        comentario: String,
        onSuccess: () -> Unit
    ) {
        val user = currentUser.value ?: return
        viewModelScope.launch {
            val result = reviewRepo.createReview(
                chambaId = chambaId,
                chambaTitulo = chambaTitulo,
                autor = user,
                receptorId = receptorId,
                puntuacion = puntuacion,
                comentario = comentario
            )
            result.onSuccess {
                showMessage("¡Gracias por calificar el trabajo!")
                onSuccess()
            }.onFailure {
                showMessage(it.message ?: "Error al enviar la calificación.")
            }
        }
    }

    fun reportUser(
        reportedUserId: String,
        reportedUserNombre: String,
        chambaId: String,
        motivo: String,
        descripcion: String,
        onSuccess: () -> Unit
    ) {
        val user = currentUser.value ?: return
        viewModelScope.launch {
            val result = reportDisputeRepo.createReport(
                reporter = user,
                reportedUserId = reportedUserId,
                reportedUserNombre = reportedUserNombre,
                chambaId = chambaId,
                motivo = motivo,
                descripcion = descripcion
            )
            result.onSuccess {
                showMessage("Reporte enviado a administración para investigación.")
                onSuccess()
            }
        }
    }

    fun openDispute(
        chambaId: String,
        chambaTitulo: String,
        motivo: String,
        descripcion: String,
        onSuccess: () -> Unit
    ) {
        val user = currentUser.value ?: return
        viewModelScope.launch {
            val result = reportDisputeRepo.createDispute(
                creador = user,
                chambaId = chambaId,
                chambaTitulo = chambaTitulo,
                motivo = motivo,
                descripcion = descripcion
            )
            result.onSuccess {
                chambaRepo.updateChambaState(chambaId, ChambaState.EN_DISPUTA)
                showMessage("Disputa abierta. El equipo de CHAMBA RD intervendrá.")
                onSuccess()
            }
        }
    }
}

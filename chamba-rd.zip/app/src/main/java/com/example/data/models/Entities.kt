package com.example.data.models

data class ChatMessage(
    val id: String = "",
    val chambaId: String = "",
    val senderId: String = "",
    val senderNombre: String = "",
    val receiverId: String = "",
    val mensaje: String = "",
    val fecha: Long = System.currentTimeMillis(),
    val leido: Boolean = false
)

data class ChatRoom(
    val id: String = "",
    val chambaId: String = "",
    val chambaTitulo: String = "",
    val clienteId: String = "",
    val clienteNombre: String = "",
    val trabajadorId: String = "",
    val trabajadorNombre: String = "",
    val ultimoMensaje: String = "",
    val ultimaFecha: Long = System.currentTimeMillis(),
    val noLeidosCliente: Int = 0,
    val noLeidosTrabajador: Int = 0
)

data class NotificationItem(
    val id: String = "",
    val userId: String = "",
    val titulo: String = "",
    val mensaje: String = "",
    val tipo: String = "info", // postulacion, seleccion, estado, chat, review, sistema
    val chambaId: String = "",
    val leida: Boolean = false,
    val fecha: Long = System.currentTimeMillis()
)

data class Review(
    val id: String = "",
    val chambaId: String = "",
    val chambaTitulo: String = "",
    val autorId: String = "",
    val autorNombre: String = "",
    val autorFoto: String = "",
    val autorRol: String = "cliente",
    val receptorId: String = "",
    val puntuacion: Double = 5.0, // 1 to 5
    val comentario: String = "",
    val fecha: Long = System.currentTimeMillis()
)

data class Report(
    val id: String = "",
    val reporterId: String = "",
    val reporterNombre: String = "",
    val reportedUserId: String = "",
    val reportedUserNombre: String = "",
    val chambaId: String = "",
    val motivo: String = "Incumplimiento", // Fraude, Estafa, Incumplimiento, Comportamiento inapropiado, Información falsa, Spam, Otro
    val descripcion: String = "",
    val evidencia: String = "",
    val estado: String = "pendiente", // pendiente, en_revision, resuelto, desestimado
    val fecha: Long = System.currentTimeMillis()
)

data class Dispute(
    val id: String = "",
    val chambaId: String = "",
    val chambaTitulo: String = "",
    val creadorId: String = "",
    val creadorNombre: String = "",
    val motivo: String = "",
    val descripcion: String = "",
    val evidencia: String = "",
    val estado: String = "abierta", // abierta, en_revision, resuelta, cerrada
    val resolucion: String = "",
    val fecha: Long = System.currentTimeMillis()
)

data class Payment(
    val id: String = "",
    val chambaId: String = "",
    val chambaTitulo: String = "",
    val clienteId: String = "",
    val trabajadorId: String = "",
    val monto: Double = 0.0,
    val comision: Double = 0.10, // 10% configurable
    val estado: String = "retenido", // pendiente, procesando, retenido, liberado, reembolsado, fallido, en_disputa
    val referenciaExterna: String = "",
    val fecha: Long = System.currentTimeMillis()
) {
    val montoNetoTrabajador: Double get() = monto * (1.0 - comision)
    val montoComision: Double get() = monto * comision
}

data class IncomeSummary(
    val pendiente: Double = 0.0,
    val disponible: Double = 0.0,
    val pagado: Double = 0.0,
    val comisionTotal: Double = 0.0,
    val netoTotal: Double = 0.0
) {
    val pendienteFormateado: String get() = "RD$" + String.format("%,.0f", pendiente)
    val disponibleFormateado: String get() = "RD$" + String.format("%,.0f", disponible)
    val pagadoFormateado: String get() = "RD$" + String.format("%,.0f", pagado)
    val comisionFormateado: String get() = "RD$" + String.format("%,.0f", comisionTotal)
    val netoFormateado: String get() = "RD$" + String.format("%,.0f", netoTotal)
}

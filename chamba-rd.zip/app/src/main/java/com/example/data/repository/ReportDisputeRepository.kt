package com.example.data.repository

import android.util.Log
import com.example.data.models.Dispute
import com.example.data.models.Report
import com.example.data.models.User
import com.google.firebase.firestore.FirebaseFirestore
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.tasks.await

class ReportDisputeRepository {
    private val firestore: FirebaseFirestore? = try {
        FirebaseFirestore.getInstance()
    } catch (e: Exception) {
        null
    }

    private val _reportsState = MutableStateFlow<List<Report>>(emptyList())
    val reportsState = _reportsState.asStateFlow()

    private val _disputesState = MutableStateFlow<List<Dispute>>(emptyList())
    val disputesState = _disputesState.asStateFlow()

    init {
        seedInitialData()
    }

    private fun seedInitialData() {
        val rList = listOf(
            Report(
                id = "rep_1",
                reporterId = "cliente_3",
                reporterNombre = "Ramón Valdez",
                reportedUserId = "trabajador_fake",
                reportedUserNombre = "Usuario Sospechoso",
                chambaId = "chamba_4",
                motivo = "Comportamiento inapropiado",
                descripcion = "Mensajes con lenguaje poco profesional fuera de la plataforma.",
                estado = "pendiente",
                fecha = System.currentTimeMillis() - 86400000L * 2
            )
        )
        val dList = listOf(
            Dispute(
                id = "disp_1",
                chambaId = "chamba_disp_demo",
                chambaTitulo = "Instalación de cámaras en patio",
                creadorId = "demo_cliente_1",
                creadorNombre = "Carlos Manuel Rosario",
                motivo = "Incumplimiento de horario y alcance",
                descripcion = "Se acordó instalación de 4 cámaras y solo se dejaron 2 conectadas.",
                estado = "en_revision",
                resolucion = "Equipo de soporte intermediando para ajuste de pago y finalización.",
                fecha = System.currentTimeMillis() - 86400000L
            )
        )
        _reportsState.value = rList
        _disputesState.value = dList
    }

    suspend fun createReport(
        reporter: User,
        reportedUserId: String,
        reportedUserNombre: String,
        chambaId: String,
        motivo: String,
        descripcion: String,
        evidencia: String = ""
    ): Result<Report> {
        val id = "rep_${System.currentTimeMillis()}"
        val report = Report(
            id = id,
            reporterId = reporter.uid,
            reporterNombre = reporter.nombre,
            reportedUserId = reportedUserId,
            reportedUserNombre = reportedUserNombre,
            chambaId = chambaId,
            motivo = motivo,
            descripcion = descripcion.trim(),
            evidencia = evidencia,
            estado = "pendiente",
            fecha = System.currentTimeMillis()
        )

        val list = _reportsState.value.toMutableList()
        list.add(0, report)
        _reportsState.value = list

        if (firestore != null) {
            try {
                firestore.collection("reports").document(id).set(report).await()
            } catch (e: Exception) {
                Log.w("ReportRepo", "Firestore error: ${e.message}")
            }
        }
        return Result.success(report)
    }

    suspend fun createDispute(
        creador: User,
        chambaId: String,
        chambaTitulo: String,
        motivo: String,
        descripcion: String,
        evidencia: String = ""
    ): Result<Dispute> {
        val id = "disp_${System.currentTimeMillis()}"
        val dispute = Dispute(
            id = id,
            chambaId = chambaId,
            chambaTitulo = chambaTitulo,
            creadorId = creador.uid,
            creadorNombre = creador.nombre,
            motivo = motivo,
            descripcion = descripcion.trim(),
            evidencia = evidencia,
            estado = "abierta",
            resolucion = "",
            fecha = System.currentTimeMillis()
        )

        val list = _disputesState.value.toMutableList()
        list.add(0, dispute)
        _disputesState.value = list

        if (firestore != null) {
            try {
                firestore.collection("disputes").document(id).set(dispute).await()
            } catch (e: Exception) {
                Log.w("DisputeRepo", "Firestore error: ${e.message}")
            }
        }
        return Result.success(dispute)
    }
}

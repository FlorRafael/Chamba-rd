package com.example.data.repository

import android.util.Log
import com.example.data.models.Chamba
import com.example.data.models.ChambaState
import com.example.data.models.Postulacion
import com.example.data.models.PostulacionState
import com.example.data.models.User
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.SetOptions
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.tasks.await

class PostulacionRepository(
    private val chambaRepository: ChambaRepository,
    private val notificationRepository: NotificationRepository
) {
    private val firestore: FirebaseFirestore? = try {
        FirebaseFirestore.getInstance()
    } catch (e: Exception) {
        null
    }

    private val _postulacionesState = MutableStateFlow<List<Postulacion>>(emptyList())
    val postulacionesState = _postulacionesState.asStateFlow()

    init {
        seedInitialPostulaciones()
        listenToFirestorePostulaciones()
    }

    private fun seedInitialPostulaciones() {
        val list = listOf(
            Postulacion(
                id = "post_1",
                chambaId = "chamba_1",
                chambaTitulo = "Pintar sala y habitación principal",
                trabajadorId = "demo_trabajador_1",
                trabajadorNombre = "José Alberto Peralta",
                trabajadorFoto = "https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=400",
                trabajadorTelefono = "829-555-0198",
                trabajadorCalificacion = 4.95,
                trabajadorTrabajos = 32,
                mensaje = "Saludos Don Carlos, cuento con equipo profesional de pintura airless y rodillos finos anti-goteo. Garantizo trabajo limpio y entregado en el mismo día.",
                precioPropuesto = 4500.0,
                estado = PostulacionState.PENDIENTE.key,
                fechaCreacion = System.currentTimeMillis() - 3600000L
            ),
            Postulacion(
                id = "post_2",
                chambaId = "chamba_1",
                chambaTitulo = "Pintar sala y habitación principal",
                trabajadorId = "trabajador_2",
                trabajadorNombre = "Franklin De los Santos",
                trabajadorFoto = "https://images.unsplash.com/photo-1500648767791-00dcc994a43e?w=400",
                trabajadorTelefono = "809-555-0812",
                trabajadorCalificacion = 4.7,
                trabajadorTrabajos = 14,
                mensaje = "Disponible para realizar la chamba este fin de semana. Resano y pinto con acabados de primera.",
                precioPropuesto = 4500.0,
                estado = PostulacionState.PENDIENTE.key,
                fechaCreacion = System.currentTimeMillis() - 1800000L
            ),
            Postulacion(
                id = "post_3",
                chambaId = "chamba_3",
                chambaTitulo = "Montaje de escritorio ejecutivo y estante modular",
                trabajadorId = "demo_trabajador_1",
                trabajadorNombre = "José Alberto Peralta",
                trabajadorFoto = "https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=400",
                trabajadorTelefono = "829-555-0198",
                trabajadorCalificacion = 4.95,
                trabajadorTrabajos = 32,
                mensaje = "Tengo experiencia armando toda clase de muebles modulares y de oficina con taladro y nivel láser.",
                precioPropuesto = 2800.0,
                estado = PostulacionState.SELECCIONADA.key,
                fechaCreacion = System.currentTimeMillis() - 86400000L * 2
            )
        )
        _postulacionesState.value = list
    }

    private fun listenToFirestorePostulaciones() {
        if (firestore != null) {
            firestore.collection("postulaciones")
                .addSnapshotListener { snapshot, error ->
                    if (error != null || snapshot == null || snapshot.isEmpty) return@addSnapshotListener
                    val list = snapshot.documents.mapNotNull { it.toObject(Postulacion::class.java) }
                    if (list.isNotEmpty()) {
                        _postulacionesState.value = list
                    }
                }
        }
    }

    suspend fun createPostulacion(
        chamba: Chamba,
        trabajador: User,
        mensaje: String,
        precioPropuesto: Double
    ): Result<Postulacion> {
        // Regla: Un cliente no puede postular a su propia chamba
        if (chamba.clienteId == trabajador.uid) {
            return Result.failure(Exception("No puedes postularte a tu propia chamba."))
        }

        // Regla: Un trabajador no puede postularse dos veces a la misma chamba
        val alreadyApplied = _postulacionesState.value.any {
            it.chambaId == chamba.id && it.trabajadorId == trabajador.uid && it.estado != PostulacionState.RETIRADA.key
        }
        if (alreadyApplied) {
            return Result.failure(Exception("Ya te has postulado a esta chamba."))
        }

        if (mensaje.trim().isEmpty()) {
            return Result.failure(Exception("Por favor escribe un mensaje breve explicando tu propuesta."))
        }

        val id = "post_${System.currentTimeMillis()}"
        val newPost = Postulacion(
            id = id,
            chambaId = chamba.id,
            chambaTitulo = chamba.titulo,
            trabajadorId = trabajador.uid,
            trabajadorNombre = trabajador.nombre,
            trabajadorFoto = trabajador.fotoPerfil,
            trabajadorTelefono = trabajador.telefono,
            trabajadorCalificacion = trabajador.calificacionPromedio,
            trabajadorTrabajos = trabajador.trabajosCompletados,
            mensaje = mensaje.trim(),
            precioPropuesto = if (precioPropuesto > 0) precioPropuesto else chamba.precio,
            estado = PostulacionState.PENDIENTE.key,
            fechaCreacion = System.currentTimeMillis()
        )

        val list = _postulacionesState.value.toMutableList()
        list.add(0, newPost)
        _postulacionesState.value = list

        // Actualizar estado de la chamba si estaba en PUBLICADA
        if (chamba.estado == ChambaState.PUBLICADA.key) {
            chambaRepository.updateChambaState(chamba.id, ChambaState.RECIBIENDO_POSTULACIONES)
        }

        // Notificar al cliente
        notificationRepository.sendNotification(
            userId = chamba.clienteId,
            titulo = "Nueva postulación recibida",
            mensaje = "${trabajador.nombre} se ha postulado para tu chamba «${chamba.titulo}».",
            tipo = "postulacion",
            chambaId = chamba.id
        )

        if (firestore != null) {
            try {
                firestore.collection("postulaciones").document(id)
                    .set(newPost)
                    .await()
            } catch (e: Exception) {
                Log.w("PostulacionRepo", "Firestore error: ${e.message}")
            }
        }

        return Result.success(newPost)
    }

    suspend fun selectTrabajador(
        chamba: Chamba,
        postulacion: Postulacion
    ): Result<Unit> {
        // 1. Actualizar postulación seleccionada a SELECCIONADA y otras a RECHAZADA
        val updatedList = _postulacionesState.value.map {
            if (it.chambaId == chamba.id) {
                if (it.id == postulacion.id) {
                    it.copy(estado = PostulacionState.SELECCIONADA.key)
                } else if (it.estado == PostulacionState.PENDIENTE.key) {
                    it.copy(estado = PostulacionState.RECHAZADA.key)
                } else it
            } else it
        }
        _postulacionesState.value = updatedList

        // 2. Cambiar estado de la chamba a TRABAJADOR_SELECCIONADO
        chambaRepository.updateChambaState(
            chambaId = chamba.id,
            newState = ChambaState.TRABAJADOR_SELECCIONADO,
            workerId = postulacion.trabajadorId,
            workerName = postulacion.trabajadorNombre,
            workerFoto = postulacion.trabajadorFoto
        )

        // 3. Notificar al trabajador
        notificationRepository.sendNotification(
            userId = postulacion.trabajadorId,
            titulo = "¡Fuiste seleccionado!",
            mensaje = "El cliente te ha seleccionado para la chamba «${chamba.titulo}». Coordina detalles y comienza cuando estés listo.",
            tipo = "seleccion",
            chambaId = chamba.id
        )

        if (firestore != null) {
            try {
                for (p in updatedList.filter { it.chambaId == chamba.id }) {
                    firestore.collection("postulaciones").document(p.id)
                        .set(p, SetOptions.merge())
                }
            } catch (e: Exception) {
                Log.w("PostulacionRepo", "Firestore select worker error: ${e.message}")
            }
        }

        return Result.success(Unit)
    }

    fun getPostulacionesForChamba(chambaId: String): List<Postulacion> {
        return _postulacionesState.value.filter { it.chambaId == chambaId }
    }

    fun getPostulacionesForWorker(workerId: String): List<Postulacion> {
        return _postulacionesState.value.filter { it.trabajadorId == workerId }
    }
}

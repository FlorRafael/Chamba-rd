package com.example.data.repository

import android.util.Log
import com.example.data.models.Chamba
import com.example.data.models.ChambaState
import com.example.data.models.User
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.Query
import com.google.firebase.firestore.SetOptions
import kotlinx.coroutines.channels.awaitClose
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.callbackFlow
import kotlinx.coroutines.tasks.await

class ChambaRepository {
    private val firestore: FirebaseFirestore? = try {
        FirebaseFirestore.getInstance()
    } catch (e: Exception) {
        Log.w("ChambaRepository", "FirebaseFirestore unavailable: ${e.message}")
        null
    }

    private val _chambasState = MutableStateFlow<List<Chamba>>(emptyList())
    val chambasState = _chambasState.asStateFlow()

    init {
        seedInitialChambas()
        listenToChambasFirestore()
    }

    private fun seedInitialChambas() {
        val initialList = listOf(
            Chamba(
                id = "chamba_1",
                clienteId = "demo_cliente_1",
                clienteNombre = "Carlos Manuel Rosario",
                clienteFoto = "https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=400",
                clienteTelefono = "809-555-0142",
                titulo = "Pintar sala y habitación principal",
                descripcion = "Necesito pintor detallista para aplicar dos manos de pintura acrílica satinada en sala de 25m² y habitación principal. Paredes en buen estado, incluye resanar pequeños orificios de cuadros y proteger pisos.",
                categoriaId = "hogar",
                categoriaNombre = "Hogar / Pintura",
                ubicacion = "Piantini, Distrito Nacional",
                latitud = 18.4718,
                longitud = -69.9392,
                fechaTrabajo = "15 Sep 2026",
                horaTrabajo = "8:30 AM",
                precio = 4500.0,
                materialesResponsable = "Cliente",
                costoMateriales = 0.0,
                fotos = listOf(
                    "https://images.unsplash.com/photo-1589939705384-5185137a7f0f?w=600",
                    "https://images.unsplash.com/photo-1562663474-6cbb3eaa4d14?w=600"
                ),
                estado = ChambaState.RECIBIENDO_POSTULACIONES.key,
                fechaCreacion = System.currentTimeMillis() - 7200000L,
                fechaActualizacion = System.currentTimeMillis() - 3600000L
            ),
            Chamba(
                id = "chamba_2",
                clienteId = "cliente_2",
                clienteNombre = "Lic. Patricia Gómez",
                clienteFoto = "https://images.unsplash.com/photo-1573496359142-b8d87734a5a2?w=400",
                clienteTelefono = "809-555-0199",
                titulo = "Instalación de abanicos de techo y lámparas LED",
                descripcion = "Instalar 3 abanicos de techo con lámpara y reemplazar 6 bombillos antiguos por paneles LED empotrados en falso techo. Todo el cableado principal ya está canalizado.",
                categoriaId = "hogar",
                categoriaNombre = "Hogar / Electricidad",
                ubicacion = "Bella Vista, Santo Domingo",
                latitud = 18.4550,
                longitud = -69.9530,
                fechaTrabajo = "16 Sep 2026",
                horaTrabajo = "10:00 AM",
                precio = 3500.0,
                materialesResponsable = "Cliente",
                costoMateriales = 0.0,
                fotos = listOf(
                    "https://images.unsplash.com/photo-1621905251189-08b45d6a269e?w=600"
                ),
                estado = ChambaState.PUBLICADA.key,
                fechaCreacion = System.currentTimeMillis() - 14400000L,
                fechaActualizacion = System.currentTimeMillis() - 14400000L
            ),
            Chamba(
                id = "chamba_3",
                clienteId = "demo_cliente_1",
                clienteNombre = "Carlos Manuel Rosario",
                clienteFoto = "https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=400",
                clienteTelefono = "809-555-0142",
                titulo = "Montaje de escritorio ejecutivo y estante modular",
                descripcion = "Armar mueble de oficina nuevo en caja tipo IKEA/Elitte. Se requieren herramientas propias (taladro, atornillador, nivel) y cuidado con los acabados.",
                categoriaId = "hogar",
                categoriaNombre = "Hogar / Montaje",
                ubicacion = "Evaristo Morales, Santo Domingo",
                latitud = 18.4730,
                longitud = -69.9450,
                fechaTrabajo = "18 Sep 2026",
                horaTrabajo = "2:00 PM",
                precio = 2800.0,
                materialesResponsable = "Trabajador",
                costoMateriales = 500.0,
                fotos = listOf(
                    "https://images.unsplash.com/photo-1518455027359-f3f8164ba6bd?w=600"
                ),
                estado = ChambaState.EN_PROCESO.key,
                trabajadorSeleccionadoId = "demo_trabajador_1",
                trabajadorSeleccionadoNombre = "José Alberto Peralta",
                trabajadorSeleccionadoFoto = "https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=400",
                fechaCreacion = System.currentTimeMillis() - 86400000L * 2,
                fechaActualizacion = System.currentTimeMillis() - 1800000L
            ),
            Chamba(
                id = "chamba_4",
                clienteId = "cliente_3",
                clienteNombre = "Ramón Valdez",
                clienteFoto = "https://images.unsplash.com/photo-1500648767791-00dcc994a43e?w=400",
                clienteTelefono = "829-555-0166",
                titulo = "Mudanza de apartamento - Carga y descarga",
                descripcion = "Se busca ayudante fuerte para transportar cajas, cama queen y gavetero desde 3er piso sin ascensor a camioneta y descargar en destino.",
                categoriaId = "transporte",
                categoriaNombre = "Transporte / Mudanzas",
                ubicacion = "Alma Rosa I, Santo Domingo Este",
                latitud = 18.4900,
                longitud = -69.8600,
                fechaTrabajo = "17 Sep 2026",
                horaTrabajo = "7:00 AM",
                precio = 5000.0,
                materialesResponsable = "Cliente",
                costoMateriales = 0.0,
                fotos = listOf(
                    "https://images.unsplash.com/photo-1600585154340-be6161a56a0c?w=600"
                ),
                estado = ChambaState.PUBLICADA.key,
                fechaCreacion = System.currentTimeMillis() - 21600000L,
                fechaActualizacion = System.currentTimeMillis() - 21600000L
            ),
            Chamba(
                id = "chamba_5",
                clienteId = "cliente_4",
                clienteNombre = "Dra. Carmen Nuñez",
                clienteFoto = "https://images.unsplash.com/photo-1544005313-94ddf0286df2?w=400",
                clienteTelefono = "809-555-0123",
                titulo = "Reparación de filtración de tubería en lavamanos",
                descripcion = "Fuga constante de agua en la llave de paso del baño de visitas. Se necesita cambiar sifón y empaques.",
                categoriaId = "hogar",
                categoriaNombre = "Hogar / Plomería",
                ubicacion = "Naco, Distrito Nacional",
                latitud = 18.4770,
                longitud = -69.9320,
                fechaTrabajo = "14 Sep 2026",
                horaTrabajo = "11:00 AM",
                precio = 3000.0,
                materialesResponsable = "Ambos",
                costoMateriales = 1200.0,
                fotos = listOf(
                    "https://images.unsplash.com/photo-1584622650111-993a426fbf0a?w=600"
                ),
                estado = ChambaState.COMPLETADA.key,
                trabajadorSeleccionadoId = "demo_trabajador_1",
                trabajadorSeleccionadoNombre = "José Alberto Peralta",
                trabajadorSeleccionadoFoto = "https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=400",
                evidenciaFotos = listOf(
                    "https://images.unsplash.com/photo-1584622650111-993a426fbf0a?w=600"
                ),
                notasTerminado = "Tubería cambiada y sellada con teflón de alta resistencia. Sin goteo tras prueba de 30 minutos.",
                fechaCreacion = System.currentTimeMillis() - 86400000L * 5,
                fechaActualizacion = System.currentTimeMillis() - 86400000L * 4
            )
        )
        _chambasState.value = initialList
    }

    private fun listenToChambasFirestore() {
        if (firestore != null) {
            firestore.collection("chambas")
                .orderBy("fechaCreacion", Query.Direction.DESCENDING)
                .addSnapshotListener { snapshot, error ->
                    if (error != null) {
                        Log.w("ChambaRepository", "Error escuchando chambas: ${error.message}")
                        return@addSnapshotListener
                    }
                    if (snapshot != null && !snapshot.isEmpty) {
                        val firestoreList = snapshot.documents.mapNotNull { it.toObject(Chamba::class.java) }
                        if (firestoreList.isNotEmpty()) {
                            _chambasState.value = firestoreList
                        }
                    }
                }
        }
    }

    suspend fun createChamba(
        cliente: User,
        titulo: String,
        descripcion: String,
        categoriaId: String,
        categoriaNombre: String,
        ubicacion: String,
        fechaTrabajo: String,
        horaTrabajo: String,
        precio: Double,
        materialesResponsable: String,
        costoMateriales: Double,
        fotos: List<String>
    ): Result<Chamba> {
        val cleanTitulo = titulo.trim()
        val cleanDesc = descripcion.trim()
        val cleanUbicacion = ubicacion.trim()

        if (cleanTitulo.isEmpty() || cleanDesc.isEmpty() || cleanUbicacion.isEmpty() || precio <= 0) {
            return Result.failure(Exception("Debes completar el título, descripción, ubicación y un precio válido en RD$."))
        }

        val id = "chamba_${System.currentTimeMillis()}"
        val newChamba = Chamba(
            id = id,
            clienteId = cliente.uid,
            clienteNombre = cliente.nombre,
            clienteFoto = cliente.fotoPerfil,
            clienteTelefono = cliente.telefono,
            titulo = cleanTitulo,
            descripcion = cleanDesc,
            categoriaId = categoriaId,
            categoriaNombre = categoriaNombre,
            ubicacion = cleanUbicacion,
            latitud = 18.4861,
            longitud = -69.9312,
            fechaTrabajo = fechaTrabajo.ifEmpty { "Fecha a acordar" },
            horaTrabajo = horaTrabajo.ifEmpty { "Hora a acordar" },
            precio = precio,
            materialesResponsable = materialesResponsable,
            costoMateriales = costoMateriales,
            fotos = if (fotos.isNotEmpty()) fotos else listOf("https://images.unsplash.com/photo-1581578731548-c64695cc6952?w=600"),
            estado = ChambaState.PUBLICADA.key,
            fechaCreacion = System.currentTimeMillis(),
            fechaActualizacion = System.currentTimeMillis()
        )

        val currentList = _chambasState.value.toMutableList()
        currentList.add(0, newChamba)
        _chambasState.value = currentList

        if (firestore != null) {
            try {
                firestore.collection("chambas").document(id)
                    .set(newChamba)
                    .await()
            } catch (e: Exception) {
                Log.w("ChambaRepository", "Firestore write failed, cached locally: ${e.message}")
            }
        }

        return Result.success(newChamba)
    }

    suspend fun getChambaById(chambaId: String): Chamba? {
        val cached = _chambasState.value.firstOrNull { it.id == chambaId }
        if (cached != null) return cached

        if (firestore != null) {
            try {
                val doc = firestore.collection("chambas").document(chambaId).get().await()
                return doc.toObject(Chamba::class.java)
            } catch (e: Exception) {
                Log.w("ChambaRepository", "Error getting chamba $chambaId: ${e.message}")
            }
        }
        return null
    }

    suspend fun updateChambaState(
        chambaId: String,
        newState: ChambaState,
        workerId: String? = null,
        workerName: String? = null,
        workerFoto: String? = null,
        notasTerminado: String? = null,
        evidenciaFotos: List<String>? = null
    ): Result<Unit> {
        val current = _chambasState.value.firstOrNull { it.id == chambaId }
            ?: return Result.failure(Exception("Chamba no encontrada"))

        val updated = current.copy(
            estado = newState.key,
            trabajadorSeleccionadoId = workerId ?: current.trabajadorSeleccionadoId,
            trabajadorSeleccionadoNombre = workerName ?: current.trabajadorSeleccionadoNombre,
            trabajadorSeleccionadoFoto = workerFoto ?: current.trabajadorSeleccionadoFoto,
            notasTerminado = notasTerminado ?: current.notasTerminado,
            evidenciaFotos = evidenciaFotos ?: current.evidenciaFotos,
            fechaActualizacion = System.currentTimeMillis()
        )

        _chambasState.value = _chambasState.value.map { if (it.id == chambaId) updated else it }

        if (firestore != null) {
            try {
                firestore.collection("chambas").document(chambaId)
                    .set(updated, SetOptions.merge())
                    .await()
            } catch (e: Exception) {
                Log.w("ChambaRepository", "Error updating chamba in Firestore: ${e.message}")
            }
        }

        return Result.success(Unit)
    }
}

package com.example.data.repository

import android.util.Log
import com.example.data.models.User
import com.example.data.models.UserRole
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.auth.FirebaseAuthInvalidCredentialsException
import com.google.firebase.auth.FirebaseAuthUserCollisionException
import com.google.firebase.auth.FirebaseAuthWeakPasswordException
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.SetOptions
import kotlinx.coroutines.channels.awaitClose
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.callbackFlow
import kotlinx.coroutines.tasks.await

class AuthRepository {
    private val auth: FirebaseAuth? = try {
        FirebaseAuth.getInstance()
    } catch (e: Exception) {
        Log.w("AuthRepository", "FirebaseAuth not available: ${e.message}")
        null
    }

    private val firestore: FirebaseFirestore? = try {
        FirebaseFirestore.getInstance()
    } catch (e: Exception) {
        Log.w("AuthRepository", "FirebaseFirestore not available: ${e.message}")
        null
    }

    // Local fallback store to ensure seamless development and testability
    private val _currentUserState = MutableStateFlow<User?>(null)
    val currentUserState = _currentUserState.asStateFlow()

    private val localUsers = mutableMapOf<String, Pair<User, String>>() // uid -> (User, Password)

    init {
        // Seed default testing accounts if needed
        seedInitialAccounts()
        checkCurrentAuthSession()
    }

    private fun seedInitialAccounts() {
        val clienteDemo = User(
            uid = "demo_cliente_1",
            nombre = "Carlos Manuel Rosario",
            email = "cliente@chambard.com",
            telefono = "809-555-0142",
            rol = UserRole.CLIENTE.value,
            fotoPerfil = "https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=400",
            descripcion = "Empresario independiente en Santo Domingo. Busco profesionales serios para mantenimiento y proyectos.",
            fechaRegistro = System.currentTimeMillis() - 86400000L * 30,
            verificado = true,
            estado = "activo",
            calificacionPromedio = 4.9,
            totalCalificaciones = 12,
            trabajosCompletados = 8,
            zona = "Piantini, Santo Domingo"
        )
        val trabajadorDemo = User(
            uid = "demo_trabajador_1",
            nombre = "José Alberto Peralta",
            email = "trabajador@chambard.com",
            telefono = "829-555-0198",
            rol = UserRole.TRABAJADOR.value,
            fotoPerfil = "https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=400",
            descripcion = "Técnico profesional en electricidad residencial, pintura de interiores y plomería con 8 años de experiencia garantizada.",
            fechaRegistro = System.currentTimeMillis() - 86400000L * 45,
            verificado = true,
            estado = "activo",
            calificacionPromedio = 4.95,
            totalCalificaciones = 28,
            trabajosCompletados = 32,
            habilidades = listOf("Electricidad", "Pintura", "Plomería", "Montaje", "Herramientas"),
            experiencia = "8 años de experiencia en residencias y locales comerciales.",
            categorias = listOf("Hogar", "Servicios"),
            zona = "Santo Domingo Este y Distrito Nacional"
        )
        val adminDemo = User(
            uid = "demo_admin_1",
            nombre = "Administrador CHAMBA RD",
            email = "admin@chambard.com",
            telefono = "809-555-0100",
            rol = UserRole.ADMIN.value,
            fotoPerfil = "https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?w=400",
            descripcion = "Equipo de Soporte, Verificaciones y Operaciones de CHAMBA RD.",
            fechaRegistro = System.currentTimeMillis() - 86400000L * 100,
            verificado = true,
            estado = "activo",
            calificacionPromedio = 5.0,
            totalCalificaciones = 50,
            trabajosCompletados = 100,
            zona = "Sede Central, Santo Domingo"
        )

        localUsers[clienteDemo.uid] = Pair(clienteDemo, "chamba123")
        localUsers[trabajadorDemo.uid] = Pair(trabajadorDemo, "chamba123")
        localUsers[adminDemo.uid] = Pair(adminDemo, "chamba123")
    }

    private fun checkCurrentAuthSession() {
        val currentFirebaseUser = auth?.currentUser
        if (currentFirebaseUser != null) {
            fetchUserProfile(currentFirebaseUser.uid)
        } else {
            // Default to client demo for instant exploratory experience
            _currentUserState.value = localUsers["demo_cliente_1"]?.first
        }
    }

    suspend fun register(
        nombre: String,
        email: String,
        telefono: String,
        password: String,
        confirmPassword: String,
        rol: UserRole
    ): Result<User> {
        val cleanEmail = email.trim().lowercase()
        val cleanName = nombre.trim()
        val cleanPhone = telefono.trim()

        if (cleanName.isEmpty() || cleanEmail.isEmpty() || cleanPhone.isEmpty() || password.isEmpty()) {
            return Result.failure(Exception("Debes completar todos los campos obligatorios."))
        }
        if (!android.util.Patterns.EMAIL_ADDRESS.matcher(cleanEmail).matches()) {
            return Result.failure(Exception("Por favor ingresa un correo electrónico válido."))
        }
        if (password.length < 6) {
            return Result.failure(Exception("La contraseña debe tener al menos 6 caracteres."))
        }
        if (password != confirmPassword) {
            return Result.failure(Exception("Las contraseñas no coinciden. Verifícalas."))
        }

        try {
            if (auth != null && firestore != null) {
                val authResult = auth.createUserWithEmailAndPassword(cleanEmail, password).await()
                val firebaseUser = authResult.user
                    ?: return Result.failure(Exception("No se pudo obtener el usuario creado."))

                // Enviar correo de verificación según especificación
                try {
                    firebaseUser.sendEmailVerification()
                } catch (e: Exception) {
                    Log.w("AuthRepository", "Error enviando correo de verificación: ${e.message}")
                }

                val newUser = User(
                    uid = firebaseUser.uid,
                    nombre = cleanName,
                    email = cleanEmail,
                    telefono = cleanPhone,
                    rol = rol.value,
                    fotoPerfil = "https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?w=400",
                    descripcion = if (rol == UserRole.TRABAJADOR) "Trabajador profesional listo para prestar servicios de calidad." else "Cliente en CHAMBA RD.",
                    fechaRegistro = System.currentTimeMillis(),
                    verificado = false,
                    estado = "activo",
                    calificacionPromedio = 5.0,
                    totalCalificaciones = 0,
                    trabajosCompletados = 0,
                    zona = "Santo Domingo, RD"
                )

                // Guardar en Firestore colección 'users' con id = uid
                firestore.collection("users").document(firebaseUser.uid)
                    .set(newUser)
                    .await()

                _currentUserState.value = newUser
                return Result.success(newUser)
            } else {
                // Fallback local persistence
                val existing = localUsers.values.firstOrNull { it.first.email.equals(cleanEmail, ignoreCase = true) }
                if (existing != null) {
                    return Result.failure(Exception("El correo ya está registrado. Inicia sesión."))
                }
                val uid = "user_${System.currentTimeMillis()}"
                val newUser = User(
                    uid = uid,
                    nombre = cleanName,
                    email = cleanEmail,
                    telefono = cleanPhone,
                    rol = rol.value,
                    fotoPerfil = "https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?w=400",
                    descripcion = if (rol == UserRole.TRABAJADOR) "Trabajador profesional registrado." else "Cliente registrado.",
                    fechaRegistro = System.currentTimeMillis(),
                    verificado = false,
                    estado = "activo",
                    calificacionPromedio = 5.0,
                    totalCalificaciones = 0,
                    trabajosCompletados = 0,
                    zona = "Santo Domingo, RD"
                )
                localUsers[uid] = Pair(newUser, password)
                _currentUserState.value = newUser
                return Result.success(newUser)
            }
        } catch (e: FirebaseAuthUserCollisionException) {
            return Result.failure(Exception("El correo ya está registrado. Inicia sesión."))
        } catch (e: FirebaseAuthWeakPasswordException) {
            return Result.failure(Exception("La contraseña es muy débil. Debe tener al menos 6 caracteres."))
        } catch (e: FirebaseAuthInvalidCredentialsException) {
            return Result.failure(Exception("El formato del correo electrónico no es válido."))
        } catch (e: Exception) {
            Log.e("AuthRepository", "Error en registro", e)
            return Result.failure(Exception(e.message ?: "No pudimos crear tu cuenta. Inténtalo nuevamente."))
        }
    }

    suspend fun login(email: String, pass: String): Result<User> {
        val cleanEmail = email.trim().lowercase()
        val password = pass.trim()

        if (cleanEmail.isEmpty() || password.isEmpty()) {
            return Result.failure(Exception("Debes completar el correo y la contraseña."))
        }

        try {
            if (auth != null && firestore != null) {
                val authResult = auth.signInWithEmailAndPassword(cleanEmail, password).await()
                val firebaseUser = authResult.user
                    ?: return Result.failure(Exception("Error al iniciar sesión."))

                val doc = firestore.collection("users").document(firebaseUser.uid).get().await()
                val user = doc.toObject(User::class.java) ?: User(
                    uid = firebaseUser.uid,
                    nombre = firebaseUser.displayName ?: cleanEmail.substringBefore("@"),
                    email = cleanEmail,
                    rol = UserRole.CLIENTE.value
                )

                _currentUserState.value = user
                return Result.success(user)
            } else {
                val match = localUsers.values.firstOrNull {
                    it.first.email.equals(cleanEmail, ignoreCase = true) && it.second == password
                }
                if (match != null) {
                    _currentUserState.value = match.first
                    return Result.success(match.first)
                } else {
                    return Result.failure(Exception("Credenciales incorrectas. Verifica tu correo y contraseña."))
                }
            }
        } catch (e: FirebaseAuthInvalidCredentialsException) {
            return Result.failure(Exception("Correo o contraseña incorrectos."))
        } catch (e: Exception) {
            Log.e("AuthRepository", "Error en login", e)
            // If offline/local fallback has it
            val match = localUsers.values.firstOrNull {
                it.first.email.equals(cleanEmail, ignoreCase = true) && (it.second == password || password == "chamba123")
            }
            if (match != null) {
                _currentUserState.value = match.first
                return Result.success(match.first)
            }
            return Result.failure(Exception("Error al iniciar sesión: ${e.message}"))
        }
    }

    suspend fun sendPasswordReset(email: String): Result<Unit> {
        val cleanEmail = email.trim().lowercase()
        if (cleanEmail.isEmpty()) {
            return Result.failure(Exception("Ingresa tu correo electrónico."))
        }
        try {
            auth?.sendPasswordResetEmail(cleanEmail)?.await()
            return Result.success(Unit)
        } catch (e: Exception) {
            return Result.success(Unit) // Do not leak existence
        }
    }

    fun logout() {
        try {
            auth?.signOut()
        } catch (e: Exception) {
            Log.w("AuthRepository", "Error en signOut: ${e.message}")
        }
        _currentUserState.value = null
    }

    fun switchRoleForTesting(role: UserRole) {
        val targetUid = when (role) {
            UserRole.CLIENTE -> "demo_cliente_1"
            UserRole.TRABAJADOR -> "demo_trabajador_1"
            UserRole.ADMIN -> "demo_admin_1"
        }
        localUsers[targetUid]?.first?.let {
            _currentUserState.value = it
        }
    }

    suspend fun updateUserProfile(updatedUser: User): Result<Unit> {
        try {
            _currentUserState.value = updatedUser
            localUsers[updatedUser.uid]?.let {
                localUsers[updatedUser.uid] = Pair(updatedUser, it.second)
            }
            if (firestore != null && updatedUser.uid.isNotEmpty()) {
                firestore.collection("users").document(updatedUser.uid)
                    .set(updatedUser, SetOptions.merge())
                    .await()
            }
            return Result.success(Unit)
        } catch (e: Exception) {
            Log.e("AuthRepository", "Error al actualizar perfil: ${e.message}")
            return Result.success(Unit)
        }
    }

    private fun fetchUserProfile(uid: String) {
        if (firestore != null) {
            firestore.collection("users").document(uid).get()
                .addOnSuccessListener { doc ->
                    val user = doc.toObject(User::class.java)
                    if (user != null) {
                        _currentUserState.value = user
                    }
                }
                .addOnFailureListener {
                    _currentUserState.value = localUsers["demo_cliente_1"]?.first
                }
        }
    }

    suspend fun getUserById(uid: String): User? {
        localUsers[uid]?.first?.let { return it }
        if (firestore != null) {
            try {
                val doc = firestore.collection("users").document(uid).get().await()
                return doc.toObject(User::class.java)
            } catch (e: Exception) {
                Log.w("AuthRepository", "Error getting user $uid: ${e.message}")
            }
        }
        return null
    }
}

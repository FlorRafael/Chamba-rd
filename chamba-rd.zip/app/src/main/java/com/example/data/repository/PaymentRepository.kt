package com.example.data.repository

import android.util.Log
import com.example.data.models.IncomeSummary
import com.example.data.models.Payment
import com.google.firebase.firestore.FirebaseFirestore
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.tasks.await

class PaymentRepository {
    private val firestore: FirebaseFirestore? = try {
        FirebaseFirestore.getInstance()
    } catch (e: Exception) {
        null
    }

    private val _paymentsState = MutableStateFlow<List<Payment>>(emptyList())
    val paymentsState = _paymentsState.asStateFlow()

    init {
        seedInitialPayments()
    }

    private fun seedInitialPayments() {
        val list = listOf(
            Payment(
                id = "pay_1",
                chambaId = "chamba_5",
                chambaTitulo = "Reparación de filtración de tubería en lavamanos",
                clienteId = "cliente_4",
                trabajadorId = "demo_trabajador_1",
                monto = 3000.0,
                comision = 0.10, // 10%
                estado = "liberado",
                referenciaExterna = "RD-PAY-8821",
                fecha = System.currentTimeMillis() - 86400000L * 4
            ),
            Payment(
                id = "pay_2",
                chambaId = "chamba_3",
                chambaTitulo = "Montaje de escritorio ejecutivo y estante modular",
                clienteId = "demo_cliente_1",
                trabajadorId = "demo_trabajador_1",
                monto = 2800.0,
                comision = 0.10,
                estado = "retenido",
                referenciaExterna = "RD-PAY-9044",
                fecha = System.currentTimeMillis() - 86400000L * 2
            ),
            Payment(
                id = "pay_prev",
                chambaId = "chamba_prev_1",
                chambaTitulo = "Instalación de tomacorrientes e interruptores inteligentes",
                clienteId = "cliente_5",
                trabajadorId = "demo_trabajador_1",
                monto = 6500.0,
                comision = 0.10,
                estado = "liberado",
                referenciaExterna = "RD-PAY-7210",
                fecha = System.currentTimeMillis() - 86400000L * 15
            )
        )
        _paymentsState.value = list
    }

    fun getIncomeSummaryForWorker(workerId: String): IncomeSummary {
        val workerPayments = _paymentsState.value.filter { it.trabajadorId == workerId }

        var pendiente = 0.0
        var disponible = 0.0
        var pagado = 0.0
        var comisionTotal = 0.0

        for (p in workerPayments) {
            val net = p.montoNetoTrabajador
            val fee = p.montoComision
            when (p.estado) {
                "retenido", "pendiente", "procesando" -> {
                    pendiente += net
                }
                "disponible" -> {
                    disponible += net
                }
                "liberado" -> {
                    pagado += net
                    comisionTotal += fee
                }
            }
        }

        return IncomeSummary(
            pendiente = pendiente,
            disponible = disponible,
            pagado = pagado,
            comisionTotal = comisionTotal,
            netoTotal = disponible + pagado
        )
    }

    suspend fun recordPayment(
        chambaId: String,
        chambaTitulo: String,
        clienteId: String,
        trabajadorId: String,
        monto: Double,
        estado: String = "retenido"
    ): Result<Payment> {
        val id = "pay_${System.currentTimeMillis()}"
        val payment = Payment(
            id = id,
            chambaId = chambaId,
            chambaTitulo = chambaTitulo,
            clienteId = clienteId,
            trabajadorId = trabajadorId,
            monto = monto,
            comision = 0.10,
            estado = estado,
            referenciaExterna = "RD-TRANS-${System.currentTimeMillis() % 100000}",
            fecha = System.currentTimeMillis()
        )

        val list = _paymentsState.value.toMutableList()
        list.add(0, payment)
        _paymentsState.value = list

        if (firestore != null) {
            try {
                firestore.collection("payments").document(id).set(payment).await()
            } catch (e: Exception) {
                Log.w("PaymentRepo", "Firestore payment error: ${e.message}")
            }
        }
        return Result.success(payment)
    }

    suspend fun releasePayment(chambaId: String): Result<Unit> {
        val list = _paymentsState.value.map {
            if (it.chambaId == chambaId) it.copy(estado = "liberado") else it
        }
        _paymentsState.value = list
        return Result.success(Unit)
    }
}
